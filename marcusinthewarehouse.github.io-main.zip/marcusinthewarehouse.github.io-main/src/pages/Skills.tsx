import { Link } from "react-router-dom";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { ArrowLeft, Plus } from "lucide-react";

const Skills = () => {
  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="container mx-auto px-6 py-8">
        <div className="flex items-center gap-4 mb-8">
          <Link to="/">
            <Button variant="outline" size="sm" className="gap-2">
              <ArrowLeft className="h-4 w-4" />
              Back to Home
            </Button>
          </Link>
        </div>
        <div className="text-center">
          <h1 className="text-5xl font-bold text-text-primary mb-4 bg-gradient-hero bg-clip-text text-transparent">
            Skills & Expertise
          </h1>
          <p className="text-xl text-text-secondary max-w-2xl mx-auto">
            Technical competencies, software proficiencies, and areas of specialization
          </p>
        </div>
      </header>

      {/* Skills Content */}
      <main className="container mx-auto px-6 pb-20">
        <div className="max-w-4xl mx-auto">
          <Card className="shadow-card border border-border/50 text-center py-16">
            <CardContent>
              <div className="mb-8">
                <div className="w-16 h-16 bg-primary/10 rounded-full flex items-center justify-center mx-auto mb-4">
                  <Plus className="h-8 w-8 text-primary" />
                </div>
                <h2 className="text-2xl font-semibold text-text-primary mb-4">
                  Skills Section Ready for Content
                </h2>
                <p className="text-text-secondary max-w-md mx-auto">
                  This section is prepared for you to add your technical skills, software proficiencies, 
                  certifications, and areas of expertise.
                </p>
              </div>
              
              <div className="text-text-muted">
                <p className="mb-4">You can add content such as:</p>
                <ul className="space-y-2 text-left max-w-md mx-auto">
                  <li className="flex gap-2">
                    <span className="text-primary">•</span>
                    <span>Programming languages (C++, MATLAB, etc.)</span>
                  </li>
                  <li className="flex gap-2">
                    <span className="text-primary">•</span>
                    <span>CAD software (SolidWorks, AutoCAD)</span>
                  </li>
                  <li className="flex gap-2">
                    <span className="text-primary">•</span>
                    <span>Engineering analysis tools</span>
                  </li>
                  <li className="flex gap-2">
                    <span className="text-primary">•</span>
                    <span>Manufacturing and fabrication</span>
                  </li>
                  <li className="flex gap-2">
                    <span className="text-primary">•</span>
                    <span>Project management</span>
                  </li>
                </ul>
              </div>
            </CardContent>
          </Card>
        </div>
      </main>
    </div>
  );
};

export default Skills;