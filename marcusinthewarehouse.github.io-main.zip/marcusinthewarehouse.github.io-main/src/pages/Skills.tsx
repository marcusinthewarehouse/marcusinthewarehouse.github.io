import { Link } from "react-router-dom";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { ArrowLeft } from "lucide-react";

/**
 * Skills & Expertise page
 *
 * This component lists hard and soft skills for Marcus. Skills are
 * defined as arrays at the top of the file for easy editing. When adding
 * more skills, update the arrays below. The layout uses Cards with
 * separate sections for hard and soft skills.
 */

// Define hard and soft skills here. These arrays are rendered below.
const HARD_SKILLS = [
  "SOLIDWORKS",
  "AutoCAD",
  "MATLAB",
  "FEA",
  "Structural design",
  "HVAC design",
  "3D printing",
  "Woodwork",
  "Basic electronics & microcontrollers (Arduino programming)",
  "Robotics systems integration",
];

const SOFT_SKILLS = [
  "Team leading",
  "Project management",
  "Communication",
  "Creativity",
  "Critical thinking",
  "Adaptability",
  "Problem solving",
  "Time management",
  "Collaboration / teamwork",
  "Leadership",
];

const Skills = () => {
  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="container mx-auto px-6 py-8">
        <div className="flex items-center gap-4 mb-8">
          <Link to="/">
            <Button variant="outline" size="sm" className="gap-2">
              <ArrowLeft className="h-4 w-4" />
              Back to Home
            </Button>
          </Link>
        </div>
        <div className="text-center">
          <h1 className="text-5xl font-bold text-text-primary mb-4 bg-gradient-hero bg-clip-text text-transparent">
            Skills &amp; Expertise
          </h1>
          <p className="text-xl text-text-secondary max-w-2xl mx-auto">
            Technical competencies, software proficiencies, and areas of specialization
          </p>
        </div>
      </header>

      {/* Skills Content */}
      <main className="container mx-auto px-6 pb-20">
        <div className="max-w-4xl mx-auto space-y-8">
          {/* Hard Skills Card */}
          <Card className="shadow-card border border-border/50">
            <CardHeader>
              <CardTitle className="text-2xl text-text-primary mb-2">
                Hard Skills
              </CardTitle>
            </CardHeader>
            <CardContent>
              <ul className="grid grid-cols-1 sm:grid-cols-2 gap-x-4 gap-y-2 list-disc list-inside">
                {HARD_SKILLS.map((skill) => (
                  <li key={skill} className="text-text-secondary">
                    {skill}
                  </li>
                ))}
              </ul>
            </CardContent>
          </Card>
          {/* Soft Skills Card */}
          <Card className="shadow-card border border-border/50">
            <CardHeader>
              <CardTitle className="text-2xl text-text-primary mb-2">
                Soft Skills
              </CardTitle>
            </CardHeader>
            <CardContent>
              <ul className="grid grid-cols-1 sm:grid-cols-2 gap-x-4 gap-y-2 list-disc list-inside">
                {SOFT_SKILLS.map((skill) => (
                  <li key={skill} className="text-text-secondary">
                    {skill}
                  </li>
                ))}
              </ul>
            </CardContent>
          </Card>
        </div>
      </main>
    </div>
  );
};

export default Skills;