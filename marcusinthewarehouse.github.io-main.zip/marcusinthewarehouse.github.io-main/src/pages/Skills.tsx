import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";

// Define lists of hard and soft skills.  These can be edited freely to
// reflect your evolving expertise without touching the markup below.
const HARD_SKILLS = [
  "SOLIDWORKS",
  "AutoCAD",
  "MATLAB",
  "FEA",
  "Structural design",
  "HVAC design",
  "3D printing",
  "Woodwork",
  "Basic electronics & microcontrollers (e.g., Arduino programming)",
  "Robotics systems integration",
];

const SOFT_SKILLS = [
  "Team leading",
  "Project management",
  "Communication",
  "Creativity",
  "Critical thinking",
  "Adaptability",
  "Problem solving",
  "Time management",
  "Collaboration / teamwork",
  "Leadership",
];

const Skills = () => {
  return (
    <div className="min-h-screen bg-background">
      <header className="container mx-auto px-6 py-8">
        <h1 className="text-5xl font-bold text-text-primary mb-4 bg-gradient-hero bg-clip-text text-transparent leading-tight">
          Skills
        </h1>
      </header>
      <main className="container mx-auto px-6 pb-20">
        <div className="grid gap-8 max-w-4xl mx-auto md:grid-cols-2">
          {/* Hard Skills Card */}
          <Card className="shadow-card border border-border/50">
            <CardHeader>
              <CardTitle className="text-2xl font-semibold text-text-primary leading-tight">
                Hard Skills
              </CardTitle>
            </CardHeader>
            <CardContent>
              <ul className="list-disc list-inside space-y-2 text-text-secondary">
                {HARD_SKILLS.map((skill) => (
                  <li key={skill}>{skill}</li>
                ))}
              </ul>
            </CardContent>
          </Card>
          {/* Soft Skills Card */}
          <Card className="shadow-card border border-border/50">
            <CardHeader>
              <CardTitle className="text-2xl font-semibold text-text-primary leading-tight">
                Soft Skills
              </CardTitle>
            </CardHeader>
            <CardContent>
              <ul className="list-disc list-inside space-y-2 text-text-secondary">
                {SOFT_SKILLS.map((skill) => (
                  <li key={skill}>{skill}</li>
                ))}
              </ul>
            </CardContent>
          </Card>
        </div>
      </main>
    </div>
  );
};

export default Skills;