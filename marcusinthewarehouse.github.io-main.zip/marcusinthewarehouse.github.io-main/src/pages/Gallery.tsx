import React from "react";
import { useParams, Link } from "react-router-dom";

interface GalleryDefinition {
  title: string;
  images: string[];
}

// Define galleries for each project and experience. To add photos,
// upload image files into `public/images/{slug}/` and list their
// paths here. Initially the arrays are empty; the page will display
// a placeholder message when no photos are available.
const GALLERIES: Record<string, GalleryDefinition> = {
  flam: { title: "FLAM @ UCI", images: [] },
  "uav-club": { title: "UAV Club @ UCI", images: [] },
  "combat-robot": { title: "Anteater Combat Robotics @ UCI", images: [] },
  "autonomous-robot": { title: "Autonomous Robot Project @ UCI", images: [] },
  "engineous-group": { title: "Mechanical Engineering Intern", images: [] },
  "freelance-design": { title: "Lead Structural Designer", images: [] },
  "berktree-tutor": { title: "Tutor", images: [] },
};

const Gallery = () => {
  const { slug } = useParams();
  const gallery = slug ? GALLERIES[slug] : undefined;

  // If the slug is invalid, show a not-found message.
  if (!gallery) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="text-center">
          <h1 className="text-2xl font-semibold text-text-primary mb-4">
            Gallery not found
          </h1>
          <Link to="/" className="text-primary hover:underline">
            Return Home
          </Link>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      <header className="container mx-auto px-6 py-8">
        <div className="flex items-center gap-4 mb-6">
          <Link to="/" className="text-text-secondary hover:text-primary">
            ← Back to Home
          </Link>
        </div>
        <h1 className="text-4xl md:text-5xl font-bold text-text-primary bg-gradient-hero bg-clip-text text-transparent">
          {gallery.title} Photos
        </h1>
      </header>
      <main className="container mx-auto px-6 py-12">
        {gallery.images.length === 0 ? (
          <p className="text-text-secondary text-lg">
            No photos available yet. Check back later!
          </p>
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-6">
            {gallery.images.map((src, idx) => (
              <a
                key={idx}
                href={src}
                target="_blank"
                rel="noopener noreferrer"
              >
                <img
                  src={src}
                  alt={`${gallery.title} ${idx + 1}`}
                  className="w-full h-auto rounded-lg shadow-md"
                  loading="lazy"
                />
              </a>
            ))}
          </div>
        )}
      </main>
    </div>
  );
};

export default Gallery;