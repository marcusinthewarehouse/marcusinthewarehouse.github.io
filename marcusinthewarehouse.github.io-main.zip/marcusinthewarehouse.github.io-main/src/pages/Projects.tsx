import { Link } from "react-router-dom";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { ArrowLeft, Calendar, Users, Wrench, Brain, Plane } from "lucide-react";

const Projects = () => {
  const projects = [
    {
      title: "FLAM @ UCI",
      role: "Empanage Engineer - Team Member",
      period: "Apr 2025 - Present",
      icon: <Plane className="h-6 w-6" />,
      description: "WWI-era aircraft restoration project collaborating with engineers and museum staff.",
      achievements: [
        "Collaborating with engineers and museum staff to restore a WWI-era aircraft, including structural and mechanical components such as wings, fuselage, tail assembly, and engine system",
        "Assisting in reverse-engineering and 3D printing replica parts to match original specifications and materials as closely as possible", 
        "Supporting the design and analysis of a ceiling suspension system to safely display the aircraft overhead, accounting for load distribution and safety requirements",
        "Gaining hands-on experience in historical materials research, structural integrity assessment, and aircraft restoration techniques"
      ]
    },
    {
      title: "UAV (Unmanned Aerial Vehicle) Club @ UCI",
      role: "Board - Project Manager",
      period: "Mar 2025 - Present", 
      icon: <Users className="h-6 w-6" />,
      description: "Leading drone design education and hands-on projects for club members.",
      achievements: [
        "Developed a structured curriculum and project timeline for club members, covering drone design, assembly, and flight fundamentals",
        "Led weekly CAD workshops using SolidWorks, focusing on drone and fixed-wing aircraft design, including custom part modeling",
        "Mentored member teams on building and troubleshooting Tiny Whoops, 5-inch racing drones, and foam or 3D printed fixed-wing planes of varying sizes",
        "Provided hands-on guidance in FPV (first-person view) drone simulations to help members improve piloting skills before field testing",
        "Supported 3D printing operations and trained members on the proper usage and maintenance of printers for drone and plane components"
      ]
    },
    {
      title: "Anteater Combat Robotics @ UCI",
      role: "Team Lead",
      period: "Sep 2024 - Feb 2025",
      icon: <Wrench className="h-6 w-6" />,
      description: "Leading the mechanical design and fabrication of custom combat robots.",
      achievements: [
        "Led the mechanical design of a custom robot, developing the chassis, gear assemblies, and weapon system from concept to fabrication without external references",
        "Employed SolidWorks for 3D modeling, optimizing movement, offense, and defense within the 1 lb weight limit",
        "Manufactured with 3D printing to achieve precise customization while maintaining a total weight under 1 lb",
        "Integrated and soldered key electrical components such as the battery, motor, ESC (electronic speed controller), switch, servo, and receiver"
      ]
    },
    {
      title: "Autonomous Robot Project @ UCI",
      role: "Software Lead",
      period: "Jan 2025 - Mar 2025",
      icon: <Brain className="h-6 w-6" />,
      description: "Developing autonomous navigation systems with advanced sensor fusion.",
      achievements: [
        "Developed and programmed an autonomous robot in C++ (Arduino) to navigate a course using a pneumatic propulsion system and servo-based steering",
        "Developed a sensor fusion system combining magnetometer and reed switch data for dead reckoning, enabling real-time heading correction and accurate trajectory adjustments",
        "Validated control logic through MATLAB simulation, comparing results using statistical analysis and performance visualization"
      ]
    }
  ];

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="container mx-auto px-6 py-8">
        <div className="flex items-center gap-4 mb-8">
          <Link to="/">
            <Button variant="outline" size="sm" className="gap-2">
              <ArrowLeft className="h-4 w-4" />
              Back to Home
            </Button>
          </Link>
        </div>
        <div className="text-center">
          <h1 className="text-5xl font-bold text-text-primary mb-4 bg-gradient-hero bg-clip-text text-transparent">
            Projects
          </h1>
          <p className="text-xl text-text-secondary max-w-2xl mx-auto">
            A collection of engineering projects spanning robotics, aerospace, and autonomous systems
          </p>
        </div>
      </header>

      {/* Projects Grid */}
      <main className="container mx-auto px-6 pb-20">
        <div className="space-y-8">
          {projects.map((project, index) => (
            <Card key={index} className="shadow-card border border-border/50 hover:shadow-glow transition-all duration-300">
              <CardHeader>
                <div className="flex items-start gap-4">
                  <div className="p-3 bg-primary/10 rounded-lg text-primary">
                    {project.icon}
                  </div>
                  <div className="flex-1">
                    <CardTitle className="text-2xl text-text-primary mb-2">
                      {project.title}
                    </CardTitle>
                    <div className="flex flex-col sm:flex-row sm:items-center gap-2 mb-3">
                      <span className="text-primary font-medium">{project.role}</span>
                      <div className="flex items-center gap-2 text-text-muted">
                        <Calendar className="h-4 w-4" />
                        <span>{project.period}</span>
                      </div>
                    </div>
                    <p className="text-text-secondary">{project.description}</p>
                  </div>
                </div>
              </CardHeader>
              <CardContent>
                <ul className="space-y-3">
                  {project.achievements.map((achievement, achievementIndex) => (
                    <li key={achievementIndex} className="flex gap-3">
                      <div className="w-2 h-2 bg-primary rounded-full mt-2 flex-shrink-0" />
                      <span className="text-text-secondary leading-relaxed">{achievement}</span>
                    </li>
                  ))}
                </ul>
              </CardContent>
            </Card>
          ))}
        </div>
      </main>
    </div>
  );
};

export default Projects;