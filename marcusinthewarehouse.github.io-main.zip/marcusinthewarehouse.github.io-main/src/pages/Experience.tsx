import { Link } from "react-router-dom";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { ArrowLeft, Calendar, Building, GraduationCap, Award } from "lucide-react";

const Experience = () => {
  const experiences = [
    {
      title: "Mechanical Engineering Intern",
      company: "Engineous Group",
      period: "Jun 2025 - Sep 2025",
      type: "Internship",
      icon: <Building className="h-6 w-6" />,
      description: "HVAC design and analysis for commercial restaurant project.",
      achievements: [
        "Calculated heating and cooling loads for a restaurant using EnergyPro, factoring in square footage of floors, windows, and doors",
        "Selected HVAC units with adequate capacity for all rooms and designed the duct system layout to ensure coverage and airflow",
        "Sized ducts to deliver required CFM to each space while accounting for pressure drops over distance, ensuring efficient performance",
        "Used AutoCAD to create the duct design and became familiar with HVAC building codes and standards throughout the project"
      ]
    },
    {
      title: "Lead Structural Designer",
      company: "Freelance Engineering Project",
      period: "Jun 2025 - Aug 2025",
      type: "Freelance",
      icon: <Building className="h-6 w-6" />,
      description: "Custom structural design for unique outdoor viewing platforms and entertainment structures.",
      achievements: [
        "Designed and modeled six custom freestanding bleacher-style structures in SolidWorks, each rated to support 5,000 lbs of live load with a minimum factor of safety of 4.5 (total structure capacity 30,000 lbs)",
        "Created a modular, treehouse-style viewing platform that fits around palm trees while remaining fully relocatable",
        "Engineered a 6-foot-tall deck structure with an integrated bar below, allowing guests to lounge above while drinks are served below",
        "Conducted FEA simulations (stress, strain, displacement) in SolidWorks to verify structural performance and safety margins",
        "Took detailed on-site measurements and worked closely with the contractor and architect to meet all technical and client requirements"
      ]
    },
    {
      title: "Tutor",
      company: "Berktree Learning Center",
      period: "Jan 2024 - May 2025",
      type: "Part-time",
      icon: <GraduationCap className="h-6 w-6" />,
      description: "Specialized mathematics tutoring from Algebra through Linear Algebra.",
      achievements: [
        "Specializing in math tutoring, covering subjects from Algebra to Calculus and Linear Algebra",
        "Conducted weekly sessions to help students achieve their academic goals by addressing their most challenging subjects",
        "Mentored students academically and personally, building strong relationships for better engagement"
      ]
    }
  ];

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <div className="bg-card/50 border-b border-border/50">
        <div className="container mx-auto px-6 py-8">
          <div className="flex items-center gap-4 mb-6">
            <Link to="/">
              <Button variant="ghost" size="sm" className="text-text-secondary hover:text-primary">
                <ArrowLeft className="h-4 w-4 mr-2" />
                Back to Home
              </Button>
            </Link>
          </div>
          <h1 className="text-4xl md:text-5xl font-bold text-text-primary bg-gradient-hero bg-clip-text text-transparent">
            Professional Experience
          </h1>
        </div>
      </div>

      <main className="container mx-auto px-6 py-12">
        <div className="max-w-4xl mx-auto space-y-8">
          {experiences.map((exp, index) => (
            <Card key={index} className="shadow-card border border-border/50 hover:shadow-glow transition-all duration-300">
              <CardHeader>
                <div className="flex items-start gap-4">
                  <div className="p-3 bg-primary/10 rounded-lg text-primary">
                    {exp.icon}
                  </div>
                  <div className="flex-1">
                    <CardTitle className="text-2xl text-text-primary mb-2">
                      {exp.title}
                    </CardTitle>
                    <div className="flex flex-col sm:flex-row sm:items-center gap-2 mb-3">
                      <span className="text-primary font-medium">{exp.company}</span>
                      <span className="text-text-muted">•</span>
                      <span className="text-accent px-2 py-1 bg-accent/10 rounded text-sm">{exp.type}</span>
                      <div className="flex items-center gap-2 text-text-muted">
                        <Calendar className="h-4 w-4" />
                        <span>{exp.period}</span>
                      </div>
                    </div>
                    <p className="text-text-secondary">{exp.description}</p>
                  </div>
                </div>
              </CardHeader>
              <CardContent>
                <ul className="space-y-3">
                  {exp.achievements.map((achievement, achievementIndex) => (
                    <li key={achievementIndex} className="flex gap-3">
                      <div className="w-2 h-2 bg-primary rounded-full mt-2 flex-shrink-0" />
                      <span className="text-text-secondary leading-relaxed">{achievement}</span>
                    </li>
                  ))}
                </ul>
              </CardContent>
            </Card>
          ))}
        </div>
      </main>
    </div>
  );
};

export default Experience;