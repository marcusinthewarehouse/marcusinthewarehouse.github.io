import { Link } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { ArrowLeft, GraduationCap, Award } from "lucide-react";

const Education = () => {
  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <div className="bg-card/50 border-b border-border/50">
        <div className="container mx-auto px-6 py-8">
          <div className="flex items-center gap-4 mb-6">
            <Link to="/">
              <Button variant="ghost" size="sm" className="text-text-secondary hover:text-primary">
                <ArrowLeft className="h-4 w-4 mr-2" />
                Back to Home
              </Button>
            </Link>
          </div>
          <h1 className="text-4xl md:text-5xl font-bold text-text-primary bg-gradient-hero bg-clip-text text-transparent">
            Education
          </h1>
        </div>
      </div>

      {/* Education Content */}
      <main className="container mx-auto px-6 py-12">
        <div className="max-w-4xl mx-auto space-y-8">
          
          {/* University Education */}
          <Card className="shadow-card border border-border/50">
            <CardHeader>
              <div className="flex items-start gap-4">
                <GraduationCap className="h-8 w-8 text-primary mt-1" />
                <div className="flex-1">
                  <CardTitle className="text-2xl text-text-primary mb-2">
                    University of California, Irvine
                  </CardTitle>
                  <p className="text-text-secondary text-lg mb-2">B.S. in Mechanical Engineering</p>
                  <p className="text-text-muted">Sep 2024 - Jun 2026</p>
                </div>
              </div>
            </CardHeader>
          </Card>

          {/* Community College */}
          <Card className="shadow-card border border-border/50">
            <CardHeader>
              <div className="flex items-start gap-4">
                <GraduationCap className="h-8 w-8 text-primary mt-1" />
                <div className="flex-1">
                  <CardTitle className="text-2xl text-text-primary mb-2">
                    Irvine Valley College
                  </CardTitle>
                  <p className="text-text-secondary text-lg mb-2">Associates in Mathematics, Physics, and Natural Sciences</p>
                  <p className="text-text-muted">Aug 2021 - May 2024</p>
                </div>
              </div>
            </CardHeader>
          </Card>

          {/* Certification */}
          <Card className="shadow-card border border-border/50">
            <CardHeader>
              <div className="flex items-start gap-4">
                <Award className="h-8 w-8 text-primary mt-1" />
                <div className="flex-1">
                  <CardTitle className="text-2xl text-text-primary mb-2">
                    Certified SolidWorks CAD Design Associate
                  </CardTitle>
                  <p className="text-text-muted">July 2024</p>
                </div>
              </div>
            </CardHeader>
          </Card>

        </div>
      </main>
    </div>
  );
};

export default Education;