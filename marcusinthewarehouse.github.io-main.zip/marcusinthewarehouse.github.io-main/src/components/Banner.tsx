import { Link } from "react-router-dom";

/**
 * Banner component
 *
 * Renders a large headline with the site owner’s name and navigation
 * links.  This banner uses the same gradient styling as the section
 * headers on the subpages (e.g. Projects, Education).  It appears
 * consistently across all pages and serves as the primary navigation
 * mechanism.  Each segment is a link that navigates to its respective
 * page; the "Marcus Hooshmand" segment links back to the home page.
 */
export default function Banner() {
  const items = [
    { label: "Marcus Hooshmand", path: "/" },
    { label: "Projects", path: "/projects" },
    { label: "Experience", path: "/experience" },
    { label: "Education", path: "/education" },
    { label: "Skills", path: "/skills" },
  ];
  return (
    <header className="container mx-auto px-6 pt-8 pb-4">
      <h1 className="text-3xl sm:text-4xl md:text-5xl font-bold flex flex-wrap gap-6 bg-gradient-hero bg-clip-text text-transparent leading-tight">
        {items.map(({ label, path }, idx) => (
          <Link key={idx} to={path} className="hover:underline">
            {label}
          </Link>
        ))}
      </h1>
    </header>
  );
}