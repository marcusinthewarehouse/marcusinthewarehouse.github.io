import { Link, useLocation } from "react-router-dom";
import { Button } from "@/components/ui/button";

// A simple navigation bar that stays at the top of every page.  It filters
// out the link representing the current route so the user isn't offered a
// redundant option.
const LINKS = [
  { key: "home", label: "Home", path: "/" },
  { key: "projects", label: "Projects", path: "/projects" },
  { key: "experience", label: "Experience", path: "/experience" },
  { key: "education", label: "Education", path: "/education" },
  { key: "skills", label: "Skills", path: "/skills" },
];

export default function NavBar() {
  const { pathname } = useLocation();
  // Determine the current top‑level route.  The split after the first slash
  // yields an empty string for the root route, which we treat as "home".
  const current = (pathname.split("/")[1] || "home").toLowerCase();
  const visibleLinks = LINKS.filter((link) => link.key !== current);
  return (
    <nav className="sticky top-0 z-50 border-b border-border/40 bg-background/70 backdrop-blur">
      <div className="container mx-auto h-14 flex items-center gap-1 px-4">
        {visibleLinks.map(({ key, label, path }) => (
          <Link key={key} to={path}>
            <Button variant="ghost" size="sm" className="font-medium">
              {label}
            </Button>
          </Link>
        ))}
      </div>
    </nav>
  );
}