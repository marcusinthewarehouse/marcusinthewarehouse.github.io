import { Link, useLocation } from "react-router-dom";
import { Button } from "@/components/ui/button";

// A persistent navigation bar that stays at the top of every page.  Unlike
// the previous version, it always displays all links (including the
// currently selected page) so the user has a consistent set of options.
// The first link uses the site owner’s name to navigate back to the home page.
const NAV_ITEMS = [
  { label: "Marcus Hooshmand", path: "/" },
  { label: "Projects", path: "/projects" },
  { label: "Experience", path: "/experience" },
  { label: "Education", path: "/education" },
  { label: "Skills", path: "/skills" },
];

export default function NavBar() {
  const { pathname } = useLocation();
  return (
    <nav className="sticky top-0 z-50 border-b border-border/40 bg-background/70 backdrop-blur">
      <div className="container mx-auto h-14 flex items-center gap-4 px-4">
        {NAV_ITEMS.map(({ label, path }) => (
          <Link key={label} to={path}>
            <Button variant="ghost" size="sm" className="font-medium">
              {label}
            </Button>
          </Link>
        ))}
      </div>
    </nav>
  );
}