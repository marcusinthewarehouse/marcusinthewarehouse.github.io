# Marcus Hooshmand Portfolio

This repository contains the source code for the portfolio website of **Marcus Hooshmand**, a mechanical engineering student at UC Irvine. The site showcases projects, professional experience, education, skills and a gallery for photos. It is built using modern front‑end tooling and deploys automatically to GitHub Pages.

## Tech Stack

The project is built with:

- [Vite](https://vitejs.dev/) for blazing‑fast development and bundling
- [React](https://react.dev/) and [TypeScript](https://www.typescriptlang.org/) for the UI
- [shadcn/ui](https://ui.shadcn.com/) and [Tailwind CSS](https://tailwindcss.com/) for accessible components and styling

## Running Locally

1. Make sure you have [Node.js](https://nodejs.org/) installed (version 18 or later).
2. Install dependencies:

```sh
npm install
```

3. Start the development server with hot reload:

```sh
npm run dev
```

4. Build for production:

```sh
npm run build
```

The production build will be output to the `dist/` directory.

## Deployment

The site is deployed to [GitHub Pages](https://pages.github.com/) using a GitHub Actions workflow. On every push to the `main` branch, the workflow builds the site and publishes the contents of `dist/` to the live URL.

If you wish to deploy manually, run `npm run build` and copy the contents of the `dist/` directory to the root of a repository named `<username>.github.io` and enable GitHub Pages.

## Project Structure

- `src/pages`: Page components (Home, Projects, Experience, Education, Skills, Gallery).
- `src/components`: Reusable UI components.
- `public`: Static assets such as the favicon and placeholder images.
- `vite.config.ts`: Vite configuration.

## Customizing

All textual content, skills, experience and project data live in the React components within `src/pages`. To add photos to projects or experiences, upload image files into the `public/images/` folder and reference them in `Gallery.tsx` by populating the `images` arrays.

Feel free to fork this repository and adapt it to your own needs!