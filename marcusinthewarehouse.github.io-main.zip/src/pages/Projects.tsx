import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import Lightbox from "@/components/Lightbox";
import { Calendar, Users, Wrench, Brain, Plane } from "lucide-react";

/**
 * Projects page
 *
 * Displays a list of engineering projects with a placeholder for a thumbnail
 * image and an overlay lightbox for additional photos.  Each project card
 * includes the project title, role, period, description and achievements.
 */
const projects = [
  {
    slug: "flam",
    title: "FLAM @ UCI",
    role: "Empennage Engineer - Team Member",
    period: "Apr 2025 - Present",
    icon: <Plane className="h-6 w-6" />,
    description:
      "WWI-era aircraft restoration project collaborating with engineers and museum staff.",
    achievements: [
      "Collaborating with engineers and museum staff to restore a WWI-era aircraft, including structural and mechanical components such as wings, fuselage, tail assembly, and engine system",
      "Assisting in reverse‑engineering and 3D printing replica parts to match original specifications and materials as closely as possible",
      "Supporting the design and analysis of a ceiling suspension system to safely display the aircraft overhead, accounting for load distribution and safety requirements",
      "Gaining hands‑on experience in historical materials research, structural integrity assessment, and aircraft restoration techniques",
    ],
    images: [] as string[],
  },
  {
    slug: "uav-club",
    title: "UAV (Unmanned Aerial Vehicle) Club @ UCI",
    role: "Board - Project Manager",
    period: "Mar 2025 - Present",
    icon: <Users className="h-6 w-6" />,
    description:
      "Leading drone design education and hands‑on projects for club members.",
    achievements: [
      "Developed a structured curriculum and project timeline for club members, covering drone design, assembly, and flight fundamentals",
      "Led weekly CAD workshops using SolidWorks, focusing on drone and fixed‑wing aircraft design, including custom part modeling",
      "Mentored member teams on building and troubleshooting Tiny Whoops, 5‑inch racing drones, and foam or 3D printed fixed‑wing planes of varying sizes",
      "Provided hands‑on guidance in FPV (first‑person view) drone simulations to help members improve piloting skills before field testing",
      "Supported 3D printing operations and trained members on the proper usage and maintenance of printers for drone and plane components",
    ],
    images: [] as string[],
  },
  {
    slug: "combat-robot",
    title: "Anteater Combat Robotics @ UCI",
    role: "Team Lead",
    period: "Sep 2024 - Feb 2025",
    icon: <Wrench className="h-6 w-6" />,
    description:
      "Leading the mechanical design and fabrication of custom combat robots.",
    achievements: [
      "Led the mechanical design of a custom robot, developing the chassis, gear assemblies, and weapon system from concept to fabrication without external references",
      "Employed SolidWorks for 3D modeling, optimizing movement, offense, and defense within the 1 lb weight limit",
      "Manufactured with 3D printing to achieve precise customization while maintaining a total weight under 1 lb",
      "Integrated and soldered key electrical components such as the battery, motor, ESC (electronic speed controller), switch, servo, and receiver",
    ],
    images: [] as string[],
  },
  {
    slug: "autonomous-robot",
    title: "Autonomous Robot Project @ UCI",
    role: "Software Lead",
    period: "Jan 2025 - Mar 2025",
    icon: <Brain className="h-6 w-6" />,
    description:
      "Developing autonomous navigation systems with advanced sensor fusion.",
    achievements: [
      "Developed and programmed an autonomous robot in C++ (Arduino) to navigate a course using a pneumatic propulsion system and servo‑based steering",
      "Developed a sensor fusion system combining magnetometer and reed switch data for dead reckoning, enabling real‑time heading correction and accurate trajectory adjustments",
      "Validated control logic through MATLAB simulation, comparing results using statistical analysis and performance visualization",
    ],
    images: [] as string[],
  },
];

interface ProjectProps {
  project: typeof projects[number];
}

const ProjectCard = ({ project }: ProjectProps) => {
  const [open, setOpen] = useState(false);
  return (
    <Card className="shadow-card border border-border/50 hover:shadow-glow transition-all duration-300 md:grid md:grid-cols-[1fr,280px] md:gap-6">
      {/* Left column: details */}
      <div className="p-6">
        <div className="flex items-start gap-4">
          <div className="p-3 bg-primary/10 rounded-lg text-primary">
            {project.icon}
          </div>
          <div className="flex-1">
            <CardTitle className="text-2xl text-text-primary mb-2 leading-tight">
              {project.title}
            </CardTitle>
            <div className="flex flex-col sm:flex-row sm:items-center gap-2 mb-3">
              <span className="text-primary font-medium">{project.role}</span>
              <div className="flex items-center gap-2 text-text-muted">
                <Calendar className="h-4 w-4" />
                <span>{project.period}</span>
              </div>
            </div>
            <p className="text-text-secondary mb-4">{project.description}</p>
          </div>
        </div>
        <ul className="space-y-3">
          {project.achievements.map((achievement, idx) => (
            <li key={idx} className="flex gap-3">
              <div className="w-2 h-2 bg-primary rounded-full mt-2 flex-shrink-0" />
              <span className="text-text-secondary leading-relaxed">
                {achievement}
              </span>
            </li>
          ))}
        </ul>
      </div>
      {/* Right column: placeholder for photo and more photos button */}
      <div className="hidden md:flex flex-col items-start p-6">
        <div className="aspect-[4/3] w-full rounded-xl border border-border/40 bg-muted/40 overflow-hidden flex items-center justify-center">
          <span className="text-text-muted text-sm">(Project Photo)</span>
        </div>
        <button
          className="mt-3 text-primary underline"
          onClick={() => setOpen(true)}
        >
          More Photos →
        </button>
      </div>
      {/* Lightbox for photos */}
      <Lightbox
        open={open}
        onClose={() => setOpen(false)}
        title={`${project.title} — Photos`}
        images={project.images}
      />
    </Card>
  );
};

const Projects = () => {
  return (
    <div className="min-h-screen bg-background">
      <header className="container mx-auto px-6 py-8">
        <h1 className="text-5xl font-bold text-text-primary mb-4 bg-gradient-hero bg-clip-text text-transparent leading-tight">
          Projects
        </h1>
      </header>
      <main className="container mx-auto px-6 pb-20">
        <div className="space-y-8">
          {projects.map((project) => (
            <ProjectCard key={project.slug} project={project} />
          ))}
        </div>
      </main>
    </div>
  );
};

export default Projects;