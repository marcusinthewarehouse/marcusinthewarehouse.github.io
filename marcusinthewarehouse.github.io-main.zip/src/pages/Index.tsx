import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Mail, Phone, ExternalLink, User } from "lucide-react";

const Index = () => {
  return (
    <div className="min-h-screen bg-background">
      {/* Top Navigation removed: global NavBar is used instead */}

      {/* Hero Section */}
      <main className="container mx-auto px-6 py-20">
        <div className="max-w-6xl mx-auto">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            {/* Left Side - Name and Info */}
            <div className="text-left">
              <h1 className="text-5xl md:text-6xl font-bold text-text-primary mb-6 bg-gradient-hero bg-clip-text text-transparent">
                Marcus Hooshmand
              </h1>
              <p className="text-xl md:text-2xl text-text-secondary mb-6">
                Mechanical Engineering Student
              </p>
              <p className="text-lg text-text-muted mb-12">
                University of California, Irvine
              </p>

              {/* Contact Information */}
              <Card className="shadow-card border border-border/50">
                <CardContent className="p-6">
                  <div className="space-y-4">
                    <div className="flex items-center gap-3">
                      <Mail className="h-5 w-5 text-primary" />
                      <a 
                        href="mailto:Marcushooshmand@gmail.com"
                        className="text-text-secondary hover:text-primary transition-colors"
                      >
                        Marcushooshmand@gmail.com
                      </a>
                    </div>
                    <div className="flex items-center gap-3">
                      <Phone className="h-5 w-5 text-primary" />
                      <a 
                        href="tel:(949)680-6695"
                        className="text-text-secondary hover:text-primary transition-colors"
                      >
                        (949) 680-6695
                      </a>
                    </div>
                    <div className="flex items-center gap-3">
                      <ExternalLink className="h-5 w-5 text-primary" />
                      <a 
                        href="https://marcushooshmand.com"
                        target="_blank"
                        rel="noopener noreferrer"
                        className="text-text-secondary hover:text-primary transition-colors"
                      >
                        Marcushooshmand.com
                      </a>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>

            {/* Right Side - Photo Placeholder */}
            <div className="flex justify-center lg:justify-end">
              <Card className="w-80 h-96 shadow-card border border-border/50 overflow-hidden">
                <CardContent className="p-0 h-full flex items-center justify-center bg-gradient-subtle">
                  <div className="text-center">
                    <User className="h-24 w-24 text-text-muted mx-auto mb-4" />
                    <p className="text-text-muted text-sm">Photo Placeholder</p>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>
        </div>
        {/* About Me section */}
        <section className="mt-12">
          <Card className="shadow-card border border-border/50 max-w-3xl mx-auto">
            <CardHeader>
              <CardTitle className="text-xl font-semibold text-text-primary leading-tight">About Me</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-text-secondary">
                {/* Write a short 2–4 sentence personal bio here about your background, interests and goals. */}
              </p>
            </CardContent>
          </Card>
        </section>
      </main>
    </div>
  );
};

export default Index;