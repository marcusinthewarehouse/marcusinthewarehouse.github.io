import { useParams, Link } from "react-router-dom";

// Define a simple mapping from slug identifiers to gallery data.  Each slug
// corresponds to a title and an array of image paths.  At the moment we
// leave the arrays empty; once real photos are uploaded to the public
// directory and added here, the lightbox will display them.
const GALLERIES: Record<
  string,
  { title: string; images: string[] }
> = {
  // Project galleries
  flam: { title: "FLAM @ UCI", images: [] },
  "uav-club": { title: "UAV Club @ UCI", images: [] },
  "combat-robot": { title: "Anteater Combat Robotics", images: [] },
  "autonomous-robot": { title: "Autonomous Robot Project", images: [] },
  // Experience galleries (lead structural designer)
  "lead-structural-designer-cad": {
    title: "Lead Structural Designer — CAD",
    images: [],
  },
  "lead-structural-designer-build": {
    title: "Lead Structural Designer — Finished Build",
    images: [],
  },
};

export default function Gallery() {
  const { slug } = useParams();
  const gallery = slug ? GALLERIES[slug] : undefined;
  if (!gallery) {
    return (
      <div className="container mx-auto px-6 py-12">
        <h2 className="text-2xl font-semibold mb-4">Gallery Not Found</h2>
        <p className="mb-4">The gallery you are looking for does not exist.</p>
        <Link to="/" className="text-primary underline">
          Return to Home
        </Link>
      </div>
    );
  }

  return (
    <div className="container mx-auto px-6 py-12">
      <div className="mb-6">
        <h1 className="text-3xl md:text-4xl font-bold text-text-primary mb-2">
          {gallery.title}
        </h1>
        <p className="text-text-secondary mb-4">
          A collection of photos for this project. Click any image to view the
          full version in a new tab.
        </p>
        {/*
          The persistent navigation bar at the top of the page provides a
          consistent way back to the home page, so we remove the redundant
          link here.  Should you wish to add additional contextual links in
          the future, insert them below.
        */}
      </div>
      <div className="grid gap-4 grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4">
        {gallery.images.length > 0 ? (
          gallery.images.map((src, idx) => (
            <a
              key={idx}
              href={src}
              target="_blank"
              rel="noreferrer"
              className="block"
            >
              <img
                src={src}
                alt={`${gallery.title} ${idx + 1}`}
                className="w-full h-full object-cover rounded-xl"
                loading="lazy"
              />
            </a>
          ))
        ) : (
          <p className="text-text-secondary col-span-full">
            No photos have been added yet.
          </p>
        )}
      </div>
    </div>
  );
}