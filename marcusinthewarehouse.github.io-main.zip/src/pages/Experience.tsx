import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
// Only import the icons we still use.  We remove the Building and
// GraduationCap imports because the per‑item icons have been removed.
import { Calendar } from "lucide-react";

const Experience = () => {
  const experiences = [
    {
      title: "Mechanical Engineering Intern",
      company: "Engineous Group",
      period: "Jun 2025 - Sep 2025",
      type: "Internship",
      // Removed the per‑item icon property and summary description.  The
      // bullet points already communicate what this role entailed.
      description: "HVAC design and analysis for commercial restaurant project.",
      achievements: [
        "Calculated heating and cooling loads for a restaurant using EnergyPro, factoring in square footage of floors, windows, and doors",
        "Selected HVAC units with adequate capacity for all rooms and designed the duct system layout to ensure coverage and airflow",
        "Sized ducts to deliver required CFM to each space while accounting for pressure drops over distance, ensuring efficient performance",
        "Used AutoCAD to create the duct design and became familiar with HVAC building codes and standards throughout the project"
      ]
    },
    {
      title: "Lead Structural Designer",
      company: "Freelance Engineering Project",
      period: "Jun 2025 - Aug 2025",
      type: "Freelance",
      // Removed the per‑item icon property and summary description.  The
      // bullet points already communicate what this role entailed.
      description: "Custom structural design for unique outdoor viewing platforms and entertainment structures.",
      achievements: [
        "Designed and modeled six custom freestanding bleacher-style structures in SolidWorks, each rated to support 5,000 lbs of live load with a minimum factor of safety of 4.5 (total structure capacity 30,000 lbs)",
        "Created a modular, treehouse-style viewing platform that fits around palm trees while remaining fully relocatable",
        "Engineered a 6-foot-tall deck structure with an integrated bar below, allowing guests to lounge above while drinks are served below",
        "Conducted FEA simulations (stress, strain, displacement) in SolidWorks to verify structural performance and safety margins",
        "Took detailed on-site measurements and worked closely with the contractor and architect to meet all technical and client requirements"
      ]
    },
    {
      title: "Tutor",
      company: "Berktree Learning Center",
      period: "Jan 2024 - May 2025",
      type: "Part-time",
      // Removed the per‑item icon property and summary description.  The
      // bullet points already communicate what this role entailed.
      description: "Specialized mathematics tutoring from Algebra through Linear Algebra.",
      achievements: [
        "Specializing in math tutoring, covering subjects from Algebra to Calculus and Linear Algebra",
        "Conducted weekly sessions to help students achieve their academic goals by addressing their most challenging subjects",
        "Mentored students academically and personally, building strong relationships for better engagement"
      ]
    }
  ];

  return (
    <div className="min-h-screen bg-background">
      {/* Page title */}
      <header className="container mx-auto px-6 py-8">
        <h1 className="text-5xl font-bold text-text-primary mb-4 bg-gradient-hero bg-clip-text text-transparent leading-tight">
          Professional Experience
        </h1>
      </header>

      <main className="container mx-auto px-6 pb-20">
        <div className="max-w-4xl mx-auto space-y-8">
          {experiences.map((exp, index) => (
            <Card
              key={index}
              className="shadow-card border border-border/50 hover:shadow-glow transition-all duration-300"
            >
              <CardHeader>
                <div className="flex items-start gap-4">
                  {/* Removed the per‑item icon to streamline the layout */}
                  <div className="flex-1">
                    {/* Highlight the title with a blue tint */}
                    <CardTitle className="text-2xl text-blue-600 mb-2 leading-tight">
                      {exp.title}
                    </CardTitle>
                    <div className="flex flex-col sm:flex-row sm:items-center gap-2 mb-3">
                      <span className="text-primary font-medium">{exp.company}</span>
                      <span className="text-text-muted">•</span>
                      <span className="text-accent px-2 py-1 bg-accent/10 rounded text-sm">
                        {exp.type}
                      </span>
                      <div className="flex items-center gap-2 text-text-muted">
                        <Calendar className="h-4 w-4" />
                        <span>{exp.period}</span>
                      </div>
                    </div>
                    {/* Removed the summary description before the bullet points */}
                  </div>
                </div>
              </CardHeader>
              <CardContent>
                <ul className="space-y-3">
                  {exp.achievements.map((achievement, achievementIndex) => (
                    <li key={achievementIndex} className="flex gap-3">
                      <div className="w-2 h-2 bg-primary rounded-full mt-2 flex-shrink-0" />
                      <span className="text-text-secondary leading-relaxed">
                        {achievement}
                      </span>
                    </li>
                  ))}
                </ul>
                {/* For the Lead Structural Designer, add special download/photos section */}
                {exp.title === "Lead Structural Designer" && (
                  <div className="mt-4 space-y-2">
                    <div>
                      <h4 className="font-medium text-text-primary">Download CAD</h4>
                      <ul className="list-disc pl-5">
                        <li>
                          <a href="/files/xxxx.zip" className="text-primary underline">
                            xxxx.zip
                          </a>
                        </li>
                      </ul>
                    </div>
                    <div>
                      <h4 className="font-medium text-text-primary">View Photos</h4>
                      <ul className="list-disc pl-5">
                        <li>
                          <a
                            href="/#/photos/lead-structural-designer-cad"
                            className="text-primary underline"
                          >
                            CAD
                          </a>
                        </li>
                        <li>
                          <a
                            href="/#/photos/lead-structural-designer-build"
                            className="text-primary underline"
                          >
                            Finished build
                          </a>
                        </li>
                      </ul>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>
          ))}
        </div>
      </main>
    </div>
  );
};

export default Experience;