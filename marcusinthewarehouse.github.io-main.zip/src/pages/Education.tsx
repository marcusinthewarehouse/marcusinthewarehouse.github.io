import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
// Remove unused icons to simplify the layout.  We no longer display
// icons next to each education entry.

const Education = () => {
  return (
    <div className="min-h-screen bg-background">
      {/* Page title */}
      <header className="container mx-auto px-6 py-8">
        <h1 className="text-5xl font-bold text-text-primary mb-4 bg-gradient-hero bg-clip-text text-transparent leading-tight">
          Education
        </h1>
      </header>

      <main className="container mx-auto px-6 pb-20">
        <div className="max-w-4xl mx-auto space-y-8">
          {/* University Education */}
          <Card className="shadow-card border border-border/50 hover:shadow-glow transition-all duration-300">
            <CardHeader>
              <div className="flex items-start gap-4">
                {/* Removed the icon for a cleaner appearance */}
                <div className="flex-1">
                  <CardTitle className="text-2xl text-blue-600 mb-2 leading-tight">
                    University of California, Irvine
                  </CardTitle>
                  {/* Removed the degree summary line to avoid redundancy before the coursework list */}
                  <p className="text-text-muted">Sep 2024 - Jun 2026</p>
                </div>
              </div>
            </CardHeader>
            <CardContent>
              <h4 className="font-medium text-text-primary mb-2">Relevant Coursework</h4>
              <ul className="list-disc pl-5 space-y-1 text-text-secondary">
                <li>Thermodynamics</li>
                <li>Circuits</li>
                <li>Fluid dynamics</li>
                <li>Vibrations</li>
                <li>Theory of machines and mechanisms</li>
                <li>Materials science</li>
                <li>Mechanics of structures</li>
                <li>Dynamics and Control of Aerospace Vehicles</li>
                <li>Heat and Mass Transfer</li>
                <li>Applied Engineering Thermodynamics</li>
                <li>Fluid Thermal Science Laboratory</li>
              </ul>
            </CardContent>
          </Card>

          {/* Community College */}
          <Card className="shadow-card border border-border/50 hover:shadow-glow transition-all duration-300">
            <CardHeader>
              <div className="flex items-start gap-4">
                {/* Removed the icon for a cleaner appearance */}
                <div className="flex-1">
                  <CardTitle className="text-2xl text-blue-600 mb-2 leading-tight">
                    Irvine Valley College
                  </CardTitle>
                  {/* Removed the associates summary line to avoid redundancy */}
                  <p className="text-text-muted">Aug 2021 - May 2024</p>
                </div>
              </div>
            </CardHeader>
            <CardContent>
              <h4 className="font-medium text-text-primary mb-2">Relevant Coursework</h4>
              <ul className="list-disc pl-5 space-y-1 text-text-secondary">
                <li>Calculus series</li>
                <li>Physics series</li>
                <li>Linear algebra</li>
                <li>Differential equations</li>
                <li>SolidWorks CAD</li>
                <li>Statics</li>
                <li>Dynamics</li>
              </ul>
            </CardContent>
          </Card>

          {/* Certification */}
          <Card className="shadow-card border border-border/50 hover:shadow-glow transition-all duration-300">
            <CardHeader>
              <div className="flex items-start gap-4">
                {/* Removed the icon for a cleaner appearance */}
                <div className="flex-1">
                  <CardTitle className="text-2xl text-blue-600 mb-2 leading-tight">
                    Certified SolidWorks CAD Design Associate
                  </CardTitle>
                  <p className="text-text-muted">July 2024</p>
                </div>
              </div>
            </CardHeader>
          </Card>

        </div>
      </main>
    </div>
  );
};

export default Education;