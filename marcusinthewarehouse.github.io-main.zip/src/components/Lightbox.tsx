import React, { useEffect } from "react";

/**
 * A simple fullscreen lightbox for displaying a gallery of images.  The modal
 * covers the entire viewport with a dark translucent backdrop.  Clicking
 * outside the content area or the close button will dismiss it.  While the
 * lightbox is open, scrolling is disabled on the underlying document.
 */
export default function Lightbox({
  open,
  onClose,
  title,
  images,
}: {
  open: boolean;
  onClose: () => void;
  title: string;
  images: string[];
}) {
  // Prevent the underlying document from scrolling while the lightbox is
  // displayed.  When the component unmounts or the `open` flag changes
  // back to false, reset the overflow property.
  useEffect(() => {
    document.body.style.overflow = open ? "hidden" : "";
    return () => {
      document.body.style.overflow = "";
    };
  }, [open]);

  if (!open) return null;
  return (
    <div
      className="fixed inset-0 z-[60] bg-black/70"
      onClick={onClose}
      role="dialog"
      aria-modal="true"
    >
      <div
        className="absolute inset-6 md:inset-10 bg-background rounded-2xl shadow-xl p-4 md:p-6 overflow-auto"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="flex items-center justify-between mb-4">
          <h3 className="text-lg md:text-xl font-semibold text-text-primary">
            {title}
          </h3>
          <button
            className="px-3 py-1 rounded-md border border-border/40 text-text-secondary hover:bg-muted/10"
            onClick={onClose}
          >
            Close
          </button>
        </div>
        <div className="grid gap-3 md:gap-4 grid-cols-1 sm:grid-cols-2 lg:grid-cols-3">
          {images.map((src, idx) => (
            <a
              key={idx}
              href={src}
              target="_blank"
              rel="noreferrer"
              className="block"
            >
              <img
                src={src}
                alt={`${title} ${idx + 1}`}
                className="w-full rounded-xl"
                loading="lazy"
              />
            </a>
          ))}
          {images.length === 0 && (
            <p className="text-text-secondary">
              No photos available yet. Check back soon!
            </p>
          )}
        </div>
      </div>
    </div>
  );
}