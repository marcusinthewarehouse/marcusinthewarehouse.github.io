import { Link, useLocation } from "react-router-dom";
import { Button } from "@/components/ui/button";

/**
 * Navigation items for the persistent banner.
 *
 * The order of items matches the intended reading order on the banner: the
 * owner's name first (which links back to the home page) followed by the
 * various sections of the site.  We intentionally include the current
 * page in this list so that the navigation always looks the same,
 * regardless of which page you are viewing.  This provides a steady visual
 * anchor as you browse the site.
 */
const NAV_ITEMS = [
  { label: "Marcus Hooshmand", path: "/" },
  { label: "Projects", path: "/projects" },
  { label: "Experience", path: "/experience" },
  { label: "Education", path: "/education" },
  { label: "Skills", path: "/skills" },
];

export default function NavBar() {
  // Keep all navigation items visible across all pages.  The first item (home)
  // is no longer enlarged so that the banner maintains a uniform, compact
  // appearance.  We also reduce the gap between items for a more subtle look.
  // We read but do not currently use the location because the banner is
  // intentionally static.  In the future we might apply an "active" style
  // based on the current URL.
  useLocation();
  return (
    <nav className="sticky top-0 z-50 border-b border-border/40 bg-background/70 backdrop-blur">
      {/*
        Use a shorter height (h-12) and tighter gap to keep the banner from
        dominating the page.  The container keeps content aligned with the
        rest of the layout.  We still rely on the built-in sm button size to
        control the height of the individual nav items.
      */}
      <div className="container mx-auto h-10 flex items-center gap-1 px-4">
        {NAV_ITEMS.map(({ label, path }) => (
          <Link key={label} to={path}>
            <Button variant="ghost" size="sm" className="font-medium text-sm">
              {label}
            </Button>
          </Link>
        ))}
      </div>
    </nav>
  );
}